
  # Créer un portfolio

  This is a code bundle for Créer un portfolio. The original project is available at https://www.figma.com/design/Nd9SB5jrevt2bPQ1ocyj9x/Cr%C3%A9er-un-portfolio.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  